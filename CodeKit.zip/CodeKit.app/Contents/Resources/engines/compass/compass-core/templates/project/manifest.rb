description "The default project layout."
stylesheet 'screen.sass', :media => 'screen, projection'
stylesheet 'print.sass',  :media => 'print'
stylesheet 'ie.sass',     :media => 'screen, projection', :condition => "IE"